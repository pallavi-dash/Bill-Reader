//
//  BillEditView.swift
//  Bill-It-SwiftUI
//
//  Created by Pallavi Dash on 25/09/19.
//  Copyright © 2019 Pallavi Dash. All rights reserved.
//

import Foundation
import SwiftUI
import Vision
import VisionKit
import Combine



//Struct to process the scanned image and store the data retrieved.
//struct BillEditView: View {
//    @Environment(\.presentationMode) private var isPresented
//    
//    @ObservedObject var billsVM: BillsViewModel
//    
//    var tempArray = [String]()
//    
//    var arrayOfAmounts = ["Total Amount", "Amount", "Total"]
//    
//    var nextIndex = 0
//    
//    var newString = ""
//    
//    //Variable to store the processed image
//    var image: UIImage?
//    
//    // Dispatch queue to perform Vision requests.
//    private let textRecognitionWorkQueue = DispatchQueue(label: "TextRecognitionQueue",
//                                                         qos: .userInitiated, attributes: [], autoreleaseFrequency: .workItem)
//    
//    // Vision requests to be performed on each image processed.
//    private var requests = [VNRequest]()
//    
//    
//    var billsData : BillInfo?
//    
//    var body: some View {
//        Text("Hello")
//        
//    }
//    
//    //mutating function that processes the text retrieved.
//    mutating func updateProcessedText() {
//        self.billsVM.isAnimating = true
//        var result = self
//        
//        let textRecognitionRequest = VNRecognizeTextRequest {(request, error) in
//            guard let observations = request.results as? [VNRecognizedTextObservation] else {
//                print("The observations are of an unexpected type.")
//                return
//            }
//            // Concatenate the recognised text from all the observations.
//            let maximumCandidates = 1
//            for observation in observations {
//                guard let candidate = observation.topCandidates(maximumCandidates).first else { continue }
//                do {
//                    let detector = try NSDataDetector(types: NSTextCheckingAllTypes)
//                    let range = NSRange(candidate.string.startIndex..<candidate.string.endIndex, in: candidate.string)
//                    detector.enumerateMatches(in: candidate.string,
//                                              options: [],
//                                              range: range) { (match, flags, _) in
//                                                guard let match = match else {
//                                                    return
//                                                }
//                                                
//                                                switch match.resultType {
//                                                case .date:
//                                                    resultingText += "Bill Date: \(candidate.string)" + "\n"
//                                                case .phoneNumber:
//                                                    resultingText += "Phone Number: \(candidate.string)" + "\n"
//                                                    
//                                                    
//                                                    
//                                                case .address:
//                                                    
//                                                    resultingText += "Address: \(candidate.string)" + "\n"
//                                                    
//                                                default:
//                                                    return
//                                                }
//                                                
//                    }
//                    
//                    
//                    result.tempArray.append(candidate.string)
//                } catch {
//                    print("handle error")
//                }
//            }
//            
//            for (_, item) in result.arrayOfAmounts.enumerated() {
//                
//                for (indexOfTemp, itemOfTemp) in result.tempArray.enumerated() {
//                    let newTempString = itemOfTemp.replacingOccurrences(of: ":", with: "").lowercased()
//                    if newTempString == item.lowercased() {
//                        result.nextIndex = indexOfTemp + 1
//                    }
//                }
//            }
//            
//            resultingText += "Total amount: \(result.tempArray[result.nextIndex])"
//        }
//        // specify the recognition level
//        textRecognitionRequest.recognitionLevel = .accurate
//        result.requests = [textRecognitionRequest]
//        
//        billsVM.isAnimating = false
//        self = result
//        
//        
//    }
//    
//    /*
//     Method name: processImage
//     Description: This method handles the image request sent
//     */
//    mutating func processImage() {
//        
//        var result = self
//        result.updateProcessedText()
//        //Clears all present text
//        resultingText = ""
//        guard let image = image else { return }
//        
//        textRecognitionWorkQueue.async {
//            if let cgImage = image.cgImage {
//                let requestHandler = VNImageRequestHandler(cgImage: cgImage, options: [:])
//                do {
//                    try requestHandler.perform(result.requests)
//                } catch {
//                    print(error)
//                }
//            }
//            
//            resultingText += "\n\n"
//            
//            let dict = ["stringValue":"\(resultingText)","type":"Food"]
//            billDetailsArray.append(dict)
//            result.billsVM.allBills.append(BillInfo(date: result.billsVM.billsData.date,
//                                                    address: result.billsVM.billsData.address,
//                                                    phoneNumber: result.billsVM.billsData.phoneNumber,
//                                                    totalAmount: result.billsVM.billsData.totalAmount,
//                                                    type: result.billsVM.billsData.type))
//            
//            print("Final dict:\(dict)")
//        }
//        self = result
//        
//        self.billsVM.isAnimating = false
//        
//    }
//}
