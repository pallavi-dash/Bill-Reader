//
//  BillDetailsView.swift
//  Bill-It-SwiftUI
//
//  Created by Pallavi Dash on 25/09/19.
//  Copyright © 2019 Pallavi Dash. All rights reserved.
//

import Foundation
import SwiftUI

struct BillDetailsView: View {
    var billingDetail: [BillInfo]
    var body: some View {
        VStack {
            List(billingDetail) { bill in
                BillDetailsCell(bills: bill)
            }
        }
    .navigationBarTitle("Bill Details")
    }
}
 
struct BillDetailsCell: View {
    let bills : BillInfo
    var body: some View {
            VStack(alignment: .leading) {
                Text("Date: \(bills.date ?? "N/A")")
                Text("Address: \(bills.address ?? "N/A")")
                Text("Phone No: \(bills.phoneNumber ?? "N/A")")
                Text("Amount: \(bills.totalAmount ?? "N/A")")
                Text("Type: \(bills.type ?? "N/A")")
        }
    }
}
