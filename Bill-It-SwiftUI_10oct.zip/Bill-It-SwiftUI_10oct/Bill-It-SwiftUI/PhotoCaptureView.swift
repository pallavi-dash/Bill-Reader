//
//  PhotoCaptureView.swift
//  Bill-It-SwiftUI
//
//  Created by Pallavi Dash on 25/09/19.
//  Copyright © 2019 Pallavi Dash. All rights reserved.
//

import Foundation
import SwiftUI
import Vision
import VisionKit

struct PhotoCaptureView: View{
    @Binding var showImagePicker: Bool
    @Binding var image: UIImage?
    
    var body: some View {
        ChooseImagePickerController(isShown: $showImagePicker, image: $image)
    }
}

//Struct to show the image picker controller
struct ChooseImagePickerController: UIViewControllerRepresentable {
    
    
    
    
    @Binding var isShown: Bool
    @Binding var image: UIImage?
    
    func makeCoordinator() -> Coordinator {
        return Coordinator(isShown1: $isShown, image1: $image)
    }
    
    func makeUIViewController(context: Context) -> UIImagePickerController {
        let imagePickerController = UIImagePickerController()
        imagePickerController.delegate = context.coordinator
        return imagePickerController
    }
    
    func updateUIViewController(_ uiViewController: UIImagePickerController, context: Context) {
        
    }
    
    class Coordinator: NSObject, UIImagePickerControllerDelegate, UINavigationControllerDelegate {
        
        @Binding var isShown: Bool
        @Binding var image: UIImage?
        
        init(isShown1: Binding<Bool>, image1: Binding<UIImage?>) {
            _isShown = isShown1
            _image = image1
        }
        
        func imagePickerControllerDidCancel(_ picker: UIImagePickerController) {
            picker.dismiss(animated: true, completion: nil)
            isShown = false
        }
        
        func imagePickerController(_ picker: UIImagePickerController, didFinishPickingMediaWithInfo info: [UIImagePickerController.InfoKey : Any]) {
            
            if let uiImage = info[.originalImage] as? UIImage {
                image =  uiImage
            }
            isShown = true
            
            picker.dismiss(animated: true, completion:nil)
            
        }
    }
}

